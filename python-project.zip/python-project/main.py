
for i in range(1, 4):
    print(f"\n===== MAHASISWA KE-{i} =====")

    tugas = float(input("Nilai Tugas: "))
    uts = float(input("Nilai UTS: "))
    uas = float(input("Nilai UAS: "))
    kehadiran = float(input("Kehadiran (%): "))

    nilai_akhir = (20/100 * tugas) + (30/100 * uts) + (50/100 * uas)

    print("Nilai Akhir:", nilai_akhir)

    if nilai_akhir >= 75 and kehadiran >= 80:
        if nilai_akhir >= 85 and kehadiran >= 90 and nilai_akhir % 2 == 0:
            print("Status: LULUS DENGAN PREDIKAT")
            print("Alasan: Nilai akhir minimal 85,")
            print("kehadiran minimal 90%, dan nilai genap.")
        else:
            print("Status: LULUS")
            print("Alasan: Nilai akhir minimal 75")
            print("dan kehadiran minimal 80%,")
            print("tetapi tidak memenuhi semua syarat predikat.")
    else:
        print("Status: BELUM LULUS")

        if nilai_akhir < 75 and kehadiran < 80:
            print("Alasan: Nilai akhir kurang dari 75")
            print("dan kehadiran kurang dari 80%.")
        elif nilai_akhir < 75:
            print("Alasan: Nilai akhir kurang dari 75.")
        else:
            print("Alasan: Kehadiran kurang dari 80%.")
